CREATE procedure q_selectSalByNo(i_no in emp.empno%TYPE, o_sal out emp.sal%TYPE) is
begin
  SELECT sal INTO o_sal FROM emp WHERE empno=i_no;
end q_selectSalByNo;
/
