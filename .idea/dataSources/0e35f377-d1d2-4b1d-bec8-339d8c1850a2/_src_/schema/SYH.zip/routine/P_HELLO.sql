CREATE procedure p_hello is
begin
  DBMS_OUTPUT.put_line('HELLO WORLD');
end p_hello;
/
