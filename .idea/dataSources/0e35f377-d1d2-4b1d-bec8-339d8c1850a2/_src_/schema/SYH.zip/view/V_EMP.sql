CREATE VIEW V_EMP AS SELECT e.empno,e.ename,e.job,e.mgr,e.hiredate,e.sal,e.comm,e.deptno,d.dname,d.loc  FROM emp e,dept d WHERE e.deptno=d.deptno
/
