CREATE VIEW V_SCORE AS SELECT sname,
       MAX(DECODE(cname,'语文'，score)) 语文，
       MAX(DECODE(cname,'数学'，score)) 数学，
       MAX(DECODE(cname,'英语'，score)) 英语
FROM tscore GROUP BY sname
/
