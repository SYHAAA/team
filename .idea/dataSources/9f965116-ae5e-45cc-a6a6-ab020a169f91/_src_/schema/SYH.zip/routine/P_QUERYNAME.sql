CREATE procedure p_queryName(i_empno IN emp.empno%TYPE) AS
--声明变量
v_ename emp.ename%TYPE;
v_sal emp.sal%TYPE;
BEGIN
  --根据用户传递的员工号码查询姓名和薪水
  SELECT ename,sal INTO v_ename,v_sal FROM emp WHERE empno=i_empno;
  --打印结果
  dbms_output.put_line('姓名：'||v_ename||'，薪水：'||v_sal);
end p_queryName;
/
